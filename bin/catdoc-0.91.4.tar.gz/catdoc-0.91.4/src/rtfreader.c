#include <stdio.h>
#include <stdlib.h>
#include "catdoc.h"

void parse_rtf(FILE *f) {
  fprintf(stderr,"RTF parser is not implemented\n");
  exit(1);
}  
